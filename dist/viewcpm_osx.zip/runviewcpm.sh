#!/usr/bin/env bash
set -e

# Change to the directory where the script is located to find the binary
cd "$(dirname "$0")"
pwd
./viewcpm.bin
